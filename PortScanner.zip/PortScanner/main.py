#   Author: WaskoP.
#   Date written: 18.11.2019.
#   First the modules are imported which will be called to use later.
import socket
import ipaddress
from datetime import datetime
#   "w+" opens or creates a new file with overwrite permissions. Printers.txt
#   is created. The range function as defined here will find all odd numbers
#   from 1 - 254 (0 and 255 are for network and broadcast addresses). If <= 19
#   print to screen and write to Printers.txt. This gives the first 10 IPs for
#   printers.
with open("Printers.txt", "w+") as Printers:
    for p in range(1, 254, 2):
        if p <= 19:
            print("Printer IPs: 192.168.0.", p, "  ",
                  "Subnet Mask 255.255.255.0")
            Printers.write("Printer IPs: 192.168.0." +
                           (str(p) + "  " +
                            "Subnet Mask 255.255.255.0" + '\n'))
#   "w+ opens or creates a new file with overwrite permissions. Hosts.txt is
#   created. The range function as defined here will find all odd numbers from
#   1 - 254 (0 and 255 are for network and broadcast addresses). If >= 19
#   print to a screen and write to Hosts.txt. This gives the remaining IPs for
#   hosts.
with open("Hosts.txt", "w+") as Hosts:
    for h in range(1, 254, 2):
        if h >= 21:
            print("Host IPs: 192.168.0.", h, "  ",
                  "Subnet Mask 255.255.255.0")
            Hosts.write("Host IPs: 192.168.0." +
                        (str(h) + "  " + "Subnet Mask 255.255.255.0" + '\n'))
#   A while loop with exception handling. Input is displayed on screen. Input
#   type has been defined as ipaddress.ip_network. If incorrect input type is
#   entered, a ValueError exception will print "please try again" to screen.
#   Once the correct input is entered the function to scan ports for given
#   network begins. Also note a datetime.now() marker is set here to measure
#   time of scan. Datetime module is used.
while True:
    try:
        network = input("Enter the desired network to scan"
                        " (MUST include Subnet Mask) - e.g 192.168.0.0/24:  ")
        mynetwork = ipaddress.ip_network(network)
    except ValueError:
        print("Not a valid network! Please try again...")
    else:
        print("Scanning for open ports: 80 and 23 on the specified network...")
        break
dt1 = datetime.now()
#   mynetwork = the network ip and netmask input by user above. Host in
#   mynetwork calls address family IPv4 (socket.AF_INET) and TCP socket
#   (socket.SOCK_STREAM) from imported modules (socket and ipaddress).
#   Socket connection timeout is set to 0.1. Result = connect to host in
#   mynetwork on given port. Connection is closed.
for host in mynetwork:
    mysocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    mysocket.settimeout(0.1)
    result = mysocket.connect_ex((str(host), int(80)))
    mysocket.close()
    # if int(host) % 2: (if you want to print to screen each odd numbered
    # connection attempt delete this and uncomment)
    # print(host)
#   If a connection is made on specified port print "host" on port is
#   open.
    if result == 0:
        print(str(host), "on port 80 is open...")
#   mynetwork = the network ip and netmask input by user above. Host in
#   mynetwork calls address family IPv4 (socket.AF_INET) and TCP socket
#   (socket.SOCK_STREAM) from imported modules (socket and ipaddress).
#   Socket connection timeout is set to 0.1. Result = connect to host in
#   mynetwork on given port. Connection is closed.
for host in mynetwork:
    mysocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    mysocket.settimeout(0.1)
    result = mysocket.connect_ex((str(host), int(23)))
    mysocket.close()
    # if int(host) % 2: (if you want to print to screen each odd numbered
    # connection attempt delete this and uncomment)
    # print(host)
#   If a connection is made on specified port print "host" on port is
#   open.
    if result == 0:
        print(str(host), "on port 23 is open...")
#   Second datetime.now() marker set. Total = 2nd marker - 1st marker.
#   Print scan completed in time taken.
dt2 = datetime.now()
total = dt2 - dt1
print("Scanning completed in: ", total)
#   Below is a function to scan a full range of ports on a specified host.
#   First a yes or no input question is asked.
#   If yes, input is defined as type socket.gethostbyname and input will
#   need to be IPv4 or Domain (Host). Prints scanning "host" now...
#   Datetime.now() marker set. Range function calls address family IPv4
#   (socket.AF_INET) and TCP socket (socket.SOCK_STREAM) from imported
#   modules (socket and ipaddress). Port range is set from 1 - 1025.
#   Connection timeout is set to 0.1. Result = connect to specified host
#   on ports 1 - 1025. Connection is closed.
fullportscan = input("Do you wish to perform a port scan"
                     " (range 1 - 1025) on a specific host? [y/n]")
if fullportscan.lower() in ["y", "yes"]:
    HostToScan = input("Enter a host to scan (IPv4 Address or Domain)"
                       " - e.g 192.168.0.1 or www.google.com: ")
    Host = socket.gethostbyname(HostToScan)
    print("Scanning", Host, "now...")
    dt1 = datetime.now()
    try:
        for port in range(1, 1025):
            # print("Scanned port:", port)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.1)
            result = sock.connect_ex((Host, port))
            sock.close()
#   If a connection is made on the specified host for port range 1 - 1025,
#   print "Port (port) Open...". Exception for Keyboard Interrupt Cyrl+C.
#   Prints "You pressed Ctrl+C". Second datetime.now() marker set. Total =
#   2nd marker - 1st marker. Print scan completed in time taken.
            if result == 0:
                print("Port {}:   Open...".format(port))
    except KeyboardInterrupt:
        print("You pressed Ctrl+C. Have yourself a lovely day!")
    dt2 = datetime.now()
    total = dt2 - dt1
    print("Scanning completed in: ", total)
#   Else not answering "y" or "yes" to fullportscan = input("Do you wish
#   to perform a port scan (range 1 - 1025) on a specific host? [y/n]"),
#   line 77, Print to screen "Well have yourself a lovely day!" and exit.
else:
    print("Well have yourself a lovely day!")
